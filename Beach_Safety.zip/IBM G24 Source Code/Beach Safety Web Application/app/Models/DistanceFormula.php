<?php

namespace App\Models;

use CodeIgniter\Model;

class DistanceFormula extends Model
{

    
}
