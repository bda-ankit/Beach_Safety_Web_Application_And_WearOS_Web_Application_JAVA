<h1>
    <?php

if(isset($error))
    echo $error;
    
if(isset($success))
    echo $success;

?>
</h1>