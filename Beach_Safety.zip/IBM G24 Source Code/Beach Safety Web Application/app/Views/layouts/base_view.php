<?php

echo $this->include("layouts/header");

echo $this->renderSection("content");

echo $this->include("layouts/footer");

?>