
# IBM Project G24

## Develop a device/solution to save the life of people drowning at beaches in tourist destinations

### Contents

- Beach Safety Web Application
    - A Web application based on PHP, jQuery, Bootstrap 5

- sosWatch SmartWatch Application
    - A WearOS Application based on Java

